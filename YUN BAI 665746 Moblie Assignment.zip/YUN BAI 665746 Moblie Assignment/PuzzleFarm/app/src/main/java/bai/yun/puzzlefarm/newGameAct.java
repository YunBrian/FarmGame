package bai.yun.puzzlefarm;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;


public class newGameAct extends AppCompatActivity implements View.OnClickListener {
    ImageButton IB_1x1, IB_1x2, IB_1x3, IB_2x1, IB_2x2, IB_2x3, IB_3x1, IB_3x2, IB_3x3;
    ImageButton opRotateClockBtn, opMoveBtn, opRotateAntiClockBtn;
    private TextView chooseTip;
    //正确的顺序0-8
    private int[] image = {R.drawable.tile1, R.drawable.tile2, R.drawable.tile3,
            R.drawable.tile4, R.drawable.tile5, R.drawable.tile6,
            R.drawable.tile7, R.drawable.tile8, R.drawable.tile9};
    private int[] imageIndex = new int[image.length];
    int last=-1;
    int next=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_game);
        initView();
        //Random pick
        disruptRandom();
    }

    //Random to array
    private void disruptRandom() {
        //all is -1
        for (int i = 0; i < imageIndex.length; i++) {
            imageIndex[i] = -1;
        }

        int rand1=-1;
        Random random = new Random();
        for (int j = 0; j <= 8; j++) {
            //Random a number
            boolean isRepeat;
            isRepeat=true;
            while (isRepeat)
            {
                rand1 = random.nextInt(imageIndex.length);
                Log.w("random_test","start");
                isRepeat=false;
                for (int i = 0; i < j; i++) {
                    if (rand1 == imageIndex[i]) {
                        isRepeat=true;
                    }
                }
            }
            Log.w("random_test",rand1+"");
            imageIndex[j]=rand1;
        }
        freshView();
    }

    //change array
    private void swap(int rand1, int rand2) {
        Log.w("swap_test",rand1+"change"+rand2);
        int temp = imageIndex[rand1];
        imageIndex[rand1] = imageIndex[rand2];
        imageIndex[rand2] = temp;

        last=-1;
        next=-1;
        freshView();
        judgeSuccess();
    }
    //judge successful
    private void judgeSuccess() {
        boolean loop = true;
        for (int i = 0; i < imageIndex.length; i++) {
            if (imageIndex[i]!=i)
            {
                loop = false;
                break;
            }

        }
        if (loop)
        {
            IB_1x1.setClickable(false);
            IB_1x2.setClickable(false);
            IB_1x3.setClickable(false);
            IB_2x1.setClickable(false);
            IB_2x2.setClickable(false);
            IB_2x3.setClickable(false);
            IB_3x1.setClickable(false);
            IB_3x2.setClickable(false);
            IB_3x3.setClickable(false);
//  There are a dialog
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Congratulations, finish the game").setPositiveButton("Yes",null);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    //freshView
    private void freshView()
    {
        IB_1x1.setImageResource(image[imageIndex[0]]);
        IB_1x2.setImageResource(image[imageIndex[1]]);
        IB_1x3.setImageResource(image[imageIndex[2]]);
        IB_2x1.setImageResource(image[imageIndex[3]]);
        IB_2x2.setImageResource(image[imageIndex[4]]);
        IB_2x3.setImageResource(image[imageIndex[5]]);
        IB_3x1.setImageResource(image[imageIndex[6]]);
        IB_3x2.setImageResource(image[imageIndex[7]]);
        IB_3x3.setImageResource(image[imageIndex[8]]);
    }

    //Initialize the control
    private void initView() {
        chooseTip=findViewById(R.id.choose_image);
        IB_1x1 = findViewById(R.id.puzzle_1x1);
        IB_1x1.setOnClickListener(this);
        IB_1x2 = findViewById(R.id.puzzle_1x2);
        IB_1x2.setOnClickListener(this);
        IB_1x3 = findViewById(R.id.puzzle_1x3);
        IB_1x3.setOnClickListener(this);
        IB_2x1 = findViewById(R.id.puzzle_2x1);
        IB_2x1.setOnClickListener(this);
        IB_2x2 = findViewById(R.id.puzzle_2x2);
        IB_2x2.setOnClickListener(this);
        IB_2x3 = findViewById(R.id.puzzle_2x3);
        IB_2x3.setOnClickListener(this);
        IB_3x1 = findViewById(R.id.puzzle_3x1);
        IB_3x1.setOnClickListener(this);
        IB_3x2 = findViewById(R.id.puzzle_3x2);
        IB_3x2.setOnClickListener(this);
        IB_3x3 = findViewById(R.id.puzzle_3x3);
        IB_3x3.setOnClickListener(this);
        opRotateClockBtn = findViewById(R.id.rotateClockBtn);
        opRotateClockBtn.setOnClickListener(this);
        opMoveBtn = findViewById(R.id.moveBtn);
        opMoveBtn.setOnClickListener(this);
        opRotateAntiClockBtn = findViewById(R.id.rotateAntiClockBtn);
        opRotateAntiClockBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int lastTip,nextTip;
        switch (view.getId()) {
            case R.id.puzzle_1x1://this picture is imageIndex[0]
                if (last==-1&&next==-1)//First Click
                {
                    last=0;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=0)//second Click
                {
                    next=0;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_1x2://this picture is imageIndex[1]
                if (last==-1&&next==-1)
                {
                    last=1;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=1)
                {
                    next=1;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_1x3://this picture is imageIndex[2]
                if (last==-1&&next==-1)
                {
                    last=2;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=2)
                {
                    next=2;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_2x1://this picture is imageIndex[3]
                if (last==-1&&next==-1)
                {
                    last=3;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=3)
                {
                    next=3;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_2x2://this picture is imageIndex[4]
                if (last==-1&&next==-1)
                {
                    last=4;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=4)
                {
                    next=4;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_2x3://this picture is imageIndex[5]
                if (last==-1&&next==-1)
                {
                    last=5;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=5)
                {
                    next=5;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_3x1://this picture is imageIndex[6]
                if (last==-1&&next==-1)
                {
                    last=6;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=6)
                {
                    next=6;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_3x2://this picture is imageIndex[7]
                if (last==-1&&next==-1)
                {
                    last=7;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=7)
                {
                    next=7;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            case R.id.puzzle_3x3://this picture is imageIndex[8]
                if (last==-1&&next==-1)
                {
                    last=8;
                    chooseTip.setText(R.string.currently_sele_p);
                }
                if (last!=-1&&next==-1&&last!=8)
                {
                    next=8;
                    lastTip=last+1;nextTip=next+1;
                    chooseTip.setText(R.string.click_move_p);
                }
                break;
            //旋转
            case R.id.rotateClockBtn:
                break;
            //交换
            case R.id.moveBtn:
                if (last!=-1&&next!=-1)
                {
                    swap(last,next);
                    chooseTip.setText(R.string.move_success);
                }
                break;
            case R.id.rotateAntiClockBtn:
                break;
            default:
        }
    }


}
