package bai.yun.puzzlefarm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /** Called when the user touches the button */
    public void newGameAct(View view){
        //Do something in response to button click
        Intent opennewGameActIntent = new Intent(getApplicationContext(),newGameAct.class);
        startActivity(opennewGameActIntent);
    }
    public void loadGameAct(View view){
        //Do something in response to button click
        Intent openloadGameActIntent = new Intent(getApplicationContext(),loadGameAct.class);
        startActivity(openloadGameActIntent);
    }
    public void helpAct(View view){
        //Do something in response to button click
        Intent openhelpActIntent = new Intent(getApplicationContext(),helpAct.class);
        startActivity(openhelpActIntent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("Activity Lifecycle", "onPause = MainActivity");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("Activity Lifecycle", "onResume = MainActivity");
    }
}