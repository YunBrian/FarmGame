package bai.yun.puzzlefarm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class loadGameAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_game);
    }
}